//for local:
// export const baseApi = "http://localhost:5000/api/v1";

//for remote:
export const baseApi = "https://keibo-client-server.vercel.app/api/v1";